<?php


$url=$_SERVER['REQUEST_URI'];

?>